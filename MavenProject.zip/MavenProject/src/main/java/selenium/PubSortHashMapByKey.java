package selenium;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Scanner;

public class PubSortHashMapByKey {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//8) program Sorting of hashmap array by Key?
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter array size");
		int size = scanner.nextInt();
		int count = 0;
		 ArrayList<Integer> arrayList = new ArrayList<Integer>();
		
		for(int i=0;i<=size-1;i++) {
		System.out.println("Enter array values" + i);
		arrayList.add(i,scanner.nextInt());
		
		}
		scanner.close();
		System.out.println(arrayList);
		
		for (int object : arrayList) {
			if(object % 2==0) count ++;
			}
		
		System.out.println("Even count" + count);
	}}
//		// Create a HashMap with some key-value pairs
//	    HashMap<String, Integer> map = new HashMap<>();
//	    map.put("Jayant", 80);
//	    map.put("Anushka", 80);
//	    map.put("Amit", 75);
//	    map.put("Abhishek", 90);
//	    map.put("Danish", 40);
//
//	    // Print the original HashMap
//	    System.out.println("Original HashMap: " + map);
//
//	    // Get all the keys of the HashMap and store them in an ArrayList
//	    ArrayList<String> keys = new ArrayList<>(map.keySet());
//
//	    // Sort the ArrayList using Collections.sort() method
//	    Collections.sort(keys);
//
//	    // Create a new LinkedHashMap to store the sorted key-value pairs
//	    LinkedHashMap<String, Integer> sortedMap = new LinkedHashMap<>();
//
//	   // Iterate over the sorted ArrayList and get the corresponding value for each key from 
//	   //the original HashMap using get() method 
//	   for (String key : keys) {
//	     // Put each key-value pair into 
//	     //the LinkedHashMap using put() method 
//	     sortedMap.put(key, map.get(key));
//	   }
//
//	   // Print 
//	   //the sorted LinkedHashMap 
//	   System.out.println("Sorted HashMap by Keys: " + sortedMap);
//		
//
//	}
//
//}
