package selenium;

public class PubPrintVowelCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//2) Loop through each element of string and print count of vowels (aeiou)?
		
		String str = "Hello World"; // input string
        int vowelCount = 0; // variable to store vowel count
        
        // convert input string to lower case
        str = str.toLowerCase();
        
        // loop through each character of input string
        for (int i = 0; i < str.length(); i++) {
            // get current character
            char ch = str.charAt(i);
            
            // check if current character is a vowel
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                // increment vowel count
                vowelCount++;
            }
        }
        
        // print vowel count
        System.out.println("Number of vowels: " + vowelCount);
		
	}

}
