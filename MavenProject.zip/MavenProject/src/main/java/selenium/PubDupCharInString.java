package selenium;

import java.util.HashMap;
import java.util.Map;

public class PubDupCharInString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//6) program to find duplicate characters in a string (aabbcc)?
		
		// Create a string with duplicates
	    String str = "aabbcc";
	    System.out.println("Original string: " + str);

	    // Create a hash map that stores each character and its frequency
	    HashMap<Character, Integer> map = new HashMap<>();
	    for (char c : str.toCharArray()) {
	      map.put(c, map.getOrDefault(c, 0) + 1);
	    }
	    System.out.println("Hash map: " + map);

	    // Iterate over the hash map and print the characters with frequency more than one
	    System.out.println("Duplicate characters are:");
	    for (Map.Entry<Character, Integer> entry : map.entrySet()) {
	      if (entry.getValue() > 1) {
	        System.out.println(entry.getKey());
	      }
	    }

	}

}
