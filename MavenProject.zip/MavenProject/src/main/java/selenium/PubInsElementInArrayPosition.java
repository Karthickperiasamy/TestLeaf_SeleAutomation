package selenium;

import java.util.ArrayList;
import java.util.Arrays;

public class PubInsElementInArrayPosition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//7)Insert element in array (like 3rd, 2rd position)?

//		
//		 // Create an array with some elements
//	    int[] arr = {1, 2, 3, 4, 5};
//	    System.out.println("Original array: " + Arrays.toString(arr));
//
//	    // Create a new array with one extra space
//	    int[] newArr = new int[arr.length + 1];
//
//	    // Get the element to be inserted and its position
//	    int x = 6; // Element to be inserted
//	    int pos = 3; // Position at which element is to be inserted
//
//	   // Copy all the elements from original array to new array until pos - 1
//	   for (int i = 0; i < pos - 1; i++) {
//	     newArr[i] = arr[i];
//	   }
//
//	   // Insert x at pos in new array
//	   newArr[pos - 1] = x;
//
//	   // Copy remaining elements from original array to new array
//	   for (int i = pos - 1; i < arr.length; i++) {
//	     newArr[i + 1] = arr[i];
//	   }
//
//	   System.out.println("New array: " + Arrays.toString(newArr));
//		
//		
		
		
		
		// Create an ArrayList with some elements
		   ArrayList<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
		   System.out.println("Original list: " + list);

		   // Get the element to be inserted and its position
		   int x = 6; // Element to be inserted
		   int pos = 3; // Position at which element is to be inserted

		   // Use add method to insert x at pos in list
		   list.add(pos - 1, x);
		   
		System.out.println("New list: " + list);
	}

}
