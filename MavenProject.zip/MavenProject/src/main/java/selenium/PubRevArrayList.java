package selenium;

import java.util.ArrayList;
import java.util.Collections;

public class PubRevArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//4) program to Reverse an array List (integer)
		
	    //create an array list of integers
	    ArrayList<Integer> al = new ArrayList<Integer>();
	    al.add(10);
	    al.add(20);
	    al.add(30);
	    al.add(40);
	    al.add(50);

	    //print original list
	    System.out.println("Original List: " + al);

	    //reverse the list using Collections.reverse()
	    Collections.reverse(al);

	    //print reversed list
	    System.out.println("Reversed List: " + al);

	}

}
