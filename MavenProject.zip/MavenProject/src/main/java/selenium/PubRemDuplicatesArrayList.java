package selenium;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

public class PubRemDuplicatesArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//5) program to remove duplicates from array list?
		
		// Create an array list with duplicates
	    ArrayList<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 1, 2));
	    System.out.println("Original list: " + list);

	    // Convert it to a set that does not allow duplicates
	    Set<Integer> set = new LinkedHashSet<>(list);
	    System.out.println("Set without duplicates: " + set);

	    // Convert it back to an array list
	    list.clear();
	    list.addAll(set);
	    System.out.println("List without duplicates: " + list);

	}

}
