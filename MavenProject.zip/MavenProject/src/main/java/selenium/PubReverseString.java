package selenium;

public class PubReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1) Write program to reverse string without using any inbuilt function?		
		String str = "Hello World"; // input string
        String reversed = ""; // empty string to store reversed string
        
        // loop from end to start of input string
        for (int i = str.length() - 1; i >= 0; i--) {
            // append each character to reversed string
            reversed = reversed + str.charAt(i);
        }
        
        // print reversed string
        System.out.println("Reversed string: " + reversed);



	}

}
