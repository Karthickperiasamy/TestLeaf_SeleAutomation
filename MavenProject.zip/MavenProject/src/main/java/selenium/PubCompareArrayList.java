package selenium;

import java.util.ArrayList;

public class PubCompareArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//3) program to compare 2 array list (String)?
		
	    // create two array lists of String type
        ArrayList<String> firstList = new ArrayList<String>();
        ArrayList<String> secondList = new ArrayList<String>();
        
        // add some elements to both lists
        firstList.add("Java");
        firstList.add("Python");
        firstList.add("C++");
        
        secondList.add("Java");
        secondList.add("Python");
        secondList.add("C++");
        
        // compare two lists using contentEquals() method
        boolean result = compareList(firstList, secondList);
        
        // print result
        System.out.println("Are two lists equal? " + result);
    }
    
    // static method to compare two lists using contentEquals() method
    public static boolean compareList(ArrayList<String> ls1, ArrayList<String> ls2) {
        
        // convert first list into string
        String str1 = ls1.toString();
        
        // convert second list into string
        String str2 = ls2.toString();
        
        // use contentEquals() method to check if two strings are equal
        return str1.contentEquals(str2);
    

		
	}

}
