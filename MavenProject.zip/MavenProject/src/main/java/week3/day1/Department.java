package week3.day1;

public class Department extends College {
	
	public void deptName() {
	System.out.println("Department Name");	
		
	}
	

}
