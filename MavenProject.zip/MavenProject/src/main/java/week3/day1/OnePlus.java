
package week3.day1;

public class OnePlus extends AndroidTV{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void playVideo() {
		System.out.println("Play the Music");
		// TODO Auto-generated method stub
		
	}

}


/*package week3.day1;

public class Samsung extends AndroidTV{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void playVideo() {
		// TODO Auto-generated method stub
		System.out.println("playVideo");
		
	}


}
*/