package week3.day1;

public class AndroidPhone extends Mobile2 {
	
	public void takeVideo() {
		System.out.println("Take Video");
	}

	
}
