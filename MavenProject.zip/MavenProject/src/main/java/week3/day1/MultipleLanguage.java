package week3.day1;

public abstract class MultipleLanguage implements Language, TestTool{
	
	public void python() {
		System.out.println("Python");
	}

	
	void ruby() {}
	
}
