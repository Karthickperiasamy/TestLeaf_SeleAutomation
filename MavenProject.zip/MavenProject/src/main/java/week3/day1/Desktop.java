package week3.day1;

public class Desktop extends Computer{

	public void desktopSize() {
		System.out.println("Desktop Size");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Desktop desktop = new Desktop();
		desktop.computerModel();
		desktop.desktopSize();
		
		

	}

}
