package week3.day1;

public interface Language {
	
	void Java();

}
