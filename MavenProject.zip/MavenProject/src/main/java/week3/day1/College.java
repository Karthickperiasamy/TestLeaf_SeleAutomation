package week3.day1;

public class College {
	
	public void collegeName() {
		System.out.println("College Name");
	}

	
	public void collegeCode() {
		System.out.println("College Code");
	}
	
	
	public void collegeRank() {
		System.out.println("College Rank");
	}
}
