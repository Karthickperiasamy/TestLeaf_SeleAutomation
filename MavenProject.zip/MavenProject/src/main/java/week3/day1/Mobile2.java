package week3.day1;

public class Mobile2 {

			
		public void sendMsg() {
			System.out.println("Send Msg");
		}
		
		public void makeCall() {
			System.out.println("Make Call");
		}
		
		
		public void saveContact() {
			System.out.println("Save Contact");
		}

	}


