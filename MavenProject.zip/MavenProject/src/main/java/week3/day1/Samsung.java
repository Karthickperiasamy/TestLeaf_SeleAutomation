package week3.day1;

public class Samsung extends AndroidTV{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void playVideo() {
		// TODO Auto-generated method stub
		System.out.println("playVideo");
		
	}


}
