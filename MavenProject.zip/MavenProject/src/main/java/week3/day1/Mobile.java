package week3.day1;

public interface Mobile {
	
	public abstract void openApp();
	public abstract void playVideo();

}
