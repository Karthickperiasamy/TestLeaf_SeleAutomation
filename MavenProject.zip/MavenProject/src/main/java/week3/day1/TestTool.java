package week3.day1;

public interface TestTool {
	
	void Selenium();

}
