package week3.day1;

public class Computer {

	public void computerModel() {
		System.out.println("Computer Model");
		
	}
}
