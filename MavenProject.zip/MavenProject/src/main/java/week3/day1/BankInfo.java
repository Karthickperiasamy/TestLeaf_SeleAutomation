package week3.day1;

public class BankInfo {
	
	public void saving() {
	System.out.println("Saving");	
	}
	
	public void fixed() {
		System.out.println("Fixed");
	}

	public void deposit() {
		System.out.println("Deposit");
	}
	
}
