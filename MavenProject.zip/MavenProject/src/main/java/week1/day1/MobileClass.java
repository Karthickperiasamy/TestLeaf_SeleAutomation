package week1.day1;

public class MobileClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int ramMmry = 5;
boolean isAnd = true;
String model = "Galaxy";
System.out.println("RAM Space= " + ramMmry);
System.out.println("Is Android: " + isAnd);
System.out.println("Phone Model= " + model);
	}

}
