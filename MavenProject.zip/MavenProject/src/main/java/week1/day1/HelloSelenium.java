package week1.day1;

public class HelloSelenium {

	public static void main(String[] args) {
		System.out.println("Hello");// TODO Auto-generated method stub

	}

}
